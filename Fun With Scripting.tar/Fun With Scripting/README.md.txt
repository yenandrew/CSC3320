Fun with Scripting Tools

Q1- We copied the file from Cumoja1's directory. This was using the CP Command. Afterwards we used the command GREP to prepare the file.
gre "^ATOM\|^CONECT\|^HETATM\|^TER\|^END" 4HKD.pdb -v > Q1.txt This made sure the selected headers were listed and exported to a Q1 Txt file.

Q2- We used the command sed -i -e "s/HETATM/ATOM  /g" -e "s/MSE/MET/g" 4HKD.pdb.1 to replace values across the file and export it to a different file.

Q3- We used awk to make a script to find the max and min of the values. We used for an if loops to check the values and replace a
interger when a value was different.

Q4- We created a file which caluclated the mean using the sume of the numbers and a count of the numbers and finally diving the two numbers.

Q5- We applied the sed command in question two with different variables and export to v2 of the file.

Q6- We used grep to sort and export the results into a txt file.

