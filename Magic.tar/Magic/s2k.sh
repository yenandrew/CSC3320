#!/bin/bash
awk '{
if (gck[1]>0)
	{sign="-"};
split($0, gck, "/");
knuts= (gck[1]*23 + gck[2])*17 + gck[3];
print knuts;
}'
