Part 2

1. We first anyalized the file teach provided. Noticed we can remove a few lines of code and condense using (gck[1]). Other math operators will stay similar as they are same.
2. Ran output. GOt similar results.
3. Using reverse we use the GCK[1] concept again, this removed 1 portion of code, rest will be kept as it is similar math operations.
4. We summed the knuts output using the commands given
5. We piped the sum to the second file
