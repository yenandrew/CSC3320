#!/bin/bash
awk '{
sign = "";
if (gck[1]<0)
	{sign = "-"} ;
gsub("-","","$0") ;
gallons = int($0/(23*17)) ;
rem = $0 % (23*17) ;
sicles = int(rem/17) ;
knuts = rem % 17 ;
result = sign gallons "/" sicles "/" knuts ;
print result ;
}'